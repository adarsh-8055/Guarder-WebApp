package com.univ.serv;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.univ.DAO.CustomerRegDAO;
import com.univ.DTO.RegistrationDTO;

/**
 * Servlet implementation class Registration
 */
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RegistrationDTO reg=new RegistrationDTO();
		reg.setCname(request.getParameter("nm"));
	    reg.setCadd(request.getParameter("add"));
	    reg.setCemail(request.getParameter("eml"));
	    reg.setCmob(Integer.parseInt(request.getParameter("mob")));
	    reg.setCunm(request.getParameter("unm"));
	    reg.setCpw(request.getParameter("pw"));
	    CustomerRegDAO cdao=new CustomerRegDAO();
	    int x=cdao.insert(reg);
	    if(x>0)
	    {
	    	response.sendRedirect("login.jsp");
	    }
	    else {
	    	response.sendRedirect("reg.jsp");	    }
	    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
