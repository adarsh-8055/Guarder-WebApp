package com.univ.DTO;

public class RegistrationDTO {
int cid,cmob;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public int getCmob() {
	return cmob;
}
public void setCmob(int cmob) {
	this.cmob = cmob;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCadd() {
	return cadd;
}
public void setCadd(String cadd) {
	this.cadd = cadd;
}
public String getCemail() {
	return cemail;
}
public void setCemail(String cemail) {
	this.cemail = cemail;
}
public String getCunm() {
	return cunm;
}
public void setCunm(String cunm) {
	this.cunm = cunm;
}
public String getCpw() {
	return cpw;
}
public void setCpw(String cpw) {
	this.cpw = cpw;
}
String cname,cadd,cemail,cunm,cpw;
}
