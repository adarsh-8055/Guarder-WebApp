package com.univ.db;
import java.sql.*;
public class DBConnection implements DBConfig {
    
	Connection con=null;
	public static Connection getConn()
	{
		Connection con=null;
		try {
			Class.forName(Driver);
			con=DriverManager.getConnection(Conn,Unm,Pw);
		}
		catch(Exception tt)
		{
			System.out.println(tt);
		}
		return con;
	}

}
