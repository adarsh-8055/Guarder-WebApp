package com.univ.db;

public interface DBConfig {
	
	String Driver="com.mysql.cj.jdbc.Driver";
	String Conn="jdbc:mysql://localhost:3306/Guarder";
	String Unm="root";
	String Pw="";
	
}
