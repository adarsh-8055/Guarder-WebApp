package com.univ.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.univ.DTO.RegistrationDTO;
import com.univ.db.DBConnection;

public class CustomerRegDAO {
	//Insert Method
	public int insert(RegistrationDTO dto)
	{
	 int x=0;
	 try {
		 Connection con=DBConnection.getConn();
		 PreparedStatement ps=con.prepareStatement("insert into customer(cname,cadd,cmob,cemail,cunm,cpw) values(?,?,?,?,?,?)");
		 ps.setString(1,dto.getCname());
		 ps.setString(2,dto.getCadd());
		 ps.setInt(3,dto.getCmob());
		 ps.setString(4,dto.getCemail());
		 ps.setString(5,dto.getCunm());
		 ps.setString(6,dto.getCpw());
		 x=ps.executeUpdate();
		 con.close();
	 }
	 catch(Exception tt)
	 {
		 System.out.println(tt);
	 }
	 return x;
	}
	//GetPassword method
	public boolean getPw(String unm,String pw)
	{
		boolean b=false;
		try {
			 Connection con=DBConnection.getConn();
			 PreparedStatement ps=con.prepareStatement("select cunm,cpw from customer where cunm=? AND cpw=?");
			 ps.setString(1, unm);
			 ps.setString(2, pw);
			 ResultSet rs=ps.executeQuery();
			 b=rs.next();
			 con.close();
			 
		}catch(Exception tt)
		{System.out.println(tt);}
	  return b;
	}
	
	

}
